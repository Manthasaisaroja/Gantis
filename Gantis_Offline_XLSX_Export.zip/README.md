# Gantis — Offline-first Android PWA (no Firebase)

This is a working source package, **not a hosted app**. To install on Android, host these static files on any HTTPS static hosting service (for example GitHub Pages or Netlify) and open the resulting URL in Chrome, then use **Install app** / **Add to Home screen**. Simply opening index.html from a ZIP does not install the PWA.

## Features
- Dashboard, Diet Plan, Daily Log, Recipes, Progress, Profile & Settings
- Sarat and Saroja local profiles; independent logs inside the app, but **not access-controlled on a shared phone**
- Weighed recipes, approximate 100/150/200/250/300 kcal variants; guide-sourced formulations distinguished from calculated estimates
- Food + supplement totals, hydration, weight/BMI, backup and restore
- No login, Firebase, cloud database, tracking SDK, AI or OCR

## Critical limitations
- Ingredient nutritional values and micronutrient coverage are provisional; do not rely on this as a complete medically validated nutrient database.
- Supplements are added manually from verified product labels in Settings.
- LocalStorage can be cleared by Android/Chrome, and data do not sync between phones. Export JSON backups regularly.
- No scheduled reminders or automatic backups.
- HTTPS hosting is still required for installation.

## Phone-only publishing option
1. Sign into GitHub in Chrome and create a **public** repository (the code is public, but it contains no personal logs or credentials).
2. Upload all files **from this folder** into the repository root (you may need Chrome Desktop site).
3. In repository Settings → Pages, choose Deploy from a branch → main / root.
4. Open the generated https://...github.io/.../ address in Chrome → Install app.
5. Repeat on the second phone; the devices will not sync.

**Do not upload your exported personal backup JSON to a public repository.**
